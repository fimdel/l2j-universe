#!/bin/bash
java -Xmx256m l2jgeoeditor.jar GeoEditor
